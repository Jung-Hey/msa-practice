package com.example.first_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
